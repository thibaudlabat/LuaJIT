#!/bin/bash
./luajit -jdump=im
